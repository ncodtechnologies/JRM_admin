self.__precacheManifest = [
  {
    "revision": "75045391629637185152",
    "url": "/admin/static/js/main.53fbf090.chunk.js"
  },
  {
    "revision": "7c4f45329e47798217a3",
    "url": "/admin/static/js/runtime~main.b3695f6e.js"
  },
  {
    "revision": "13943cf98cb383481795",
    "url": "/admin/static/css/2.11692b6d.chunk.css"
  },
  {
    "revision": "13943cf98cb383481795",
    "url": "/admin/static/js/2.ea442522.chunk.js"
  },
  {
    "revision": "8409656035f8425ed38ba48228030dd7",
    "url": "/admin/static/media/user.84096560.png"
  },
  {
    "revision": "a2b5b8e94e15500866278289e0fbdc6f",
    "url": "/admin/static/media/news.a2b5b8e9.png"
  },
  {
    "revision": "1cedb6e919bfed6a2c1ec00b5d8ee620",
    "url": "/admin/static/media/UploadIcon.1cedb6e9.svg"
  },
  {
    "revision": "58485c2b7946b7a74d425dc59c44be00",
    "url": "/admin/index.html"
  }
];