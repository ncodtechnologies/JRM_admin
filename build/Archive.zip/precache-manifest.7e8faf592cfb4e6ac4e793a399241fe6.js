self.__precacheManifest = [
  {
    "revision": "883e0f8204156b94462c",
    "url": "/admin/static/js/main.cda600e6.chunk.js"
  },
  {
    "revision": "7c4f45329e47798217a3",
    "url": "/admin/static/js/runtime~main.b3695f6e.js"
  },
  {
    "revision": "445b215e4b1cb18dd978",
    "url": "/admin/static/css/2.11692b6d.chunk.css"
  },
  {
    "revision": "445b215e4b1cb18dd978",
    "url": "/admin/static/js/2.efd44246.chunk.js"
  },
  {
    "revision": "8409656035f8425ed38ba48228030dd7",
    "url": "/admin/static/media/user.84096560.png"
  },
  {
    "revision": "a2b5b8e94e15500866278289e0fbdc6f",
    "url": "/admin/static/media/news.a2b5b8e9.png"
  },
  {
    "revision": "1cedb6e919bfed6a2c1ec00b5d8ee620",
    "url": "/admin/static/media/UploadIcon.1cedb6e9.svg"
  },
  {
    "revision": "0d9f9d6a5ef9027281cd5bb7cf323620",
    "url": "/admin/index.html"
  }
];